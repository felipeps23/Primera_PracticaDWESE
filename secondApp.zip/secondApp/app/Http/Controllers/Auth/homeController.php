<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RutaController extends Controller
{
      public function home(){
        return View('home.home');
    }
    
}
